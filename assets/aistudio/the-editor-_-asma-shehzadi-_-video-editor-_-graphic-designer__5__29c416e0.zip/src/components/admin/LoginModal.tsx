import React, { useState } from 'react';
import { Lock, Shield, ArrowRight, AlertCircle, Eye, EyeOff, KeyRound } from 'lucide-react';
import { loginAdmin, getActiveCredentialsInfo } from '../../services/api';

interface LoginModalProps {
  onSuccess: (token: string, user: any) => void;
  onCancel: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onSuccess, onCancel }) => {
  const credsInfo = getActiveCredentialsInfo();
  const [username, setUsername] = useState(credsInfo.username);
  const [password, setPassword] = useState(credsInfo.isCustom ? '' : 'editor2026');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const res = await loginAdmin(username, password);
      onSuccess(res.token, res.user);
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-md p-8 rounded-3xl bg-neutral-950 border border-white/10 shadow-2xl space-y-6">
        {/* Brand header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 mx-auto flex items-center justify-center shadow-lg">
            <Shield className="w-7 h-7" />
          </div>
          <h2 className="text-2xl font-extrabold text-neutral-100">
            Admin CMS Login
          </h2>
          <p className="text-xs text-neutral-400">
            Secure control panel for <strong>The Editor — Asma Shehzadi</strong>
          </p>
        </div>

        {error && (
          <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Credentials Status Hint */}
        {credsInfo.isCustom ? (
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-amber-400">
              <KeyRound className="w-3.5 h-3.5" />
              <span>Custom Admin Credentials Active</span>
            </div>
            <p className="text-neutral-300 text-[11px]">
              Login using your updated admin username (<strong className="text-amber-200">{credsInfo.username}</strong>) and new password. The old default password is no longer valid.
            </p>
          </div>
        ) : (
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
            <p className="font-semibold text-amber-400">Default Access Credentials:</p>
            <div className="mt-1 flex items-center justify-between text-neutral-300">
              <span>Username: <strong className="text-amber-200">admin</strong></span>
              <span>Password: <strong className="text-amber-200">editor2026</strong></span>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Username or Email
            </label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-white/10 bg-neutral-900 text-neutral-100 focus:outline-none focus:border-amber-400 text-sm"
              placeholder="admin or asmashehzadi200@gmail.com"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 pr-11 rounded-xl border border-white/10 bg-neutral-900 text-neutral-100 focus:outline-none focus:border-amber-400 text-sm"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="w-1/3 py-3 rounded-xl border border-white/10 hover:bg-neutral-900 text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="w-2/3 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-neutral-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-98"
            >
              <span>{isLoading ? 'Verifying...' : 'Login to Dashboard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
