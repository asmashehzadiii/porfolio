import React, { useState } from 'react';
import { WebsiteData, HeroSection, AboutSection } from '../../types';
import { Sparkles, Image, Upload, Plus, Trash2, CheckCircle2, User, FileText } from 'lucide-react';
import { uploadMediaFile } from '../../services/api';

interface ContentEditorTabProps {
  data: WebsiteData;
  onChange: (newData: WebsiteData) => void;
  token: string;
}

export const ContentEditorTab: React.FC<ContentEditorTabProps> = ({ data, onChange, token }) => {
  const [subTab, setSubTab] = useState<'hero' | 'about'>('hero');
  const [uploadingImage, setUploadingImage] = useState<string | null>(null);

  const hero = data.hero;
  const about = data.about;

  const updateHero = (field: keyof HeroSection, value: any) => {
    onChange({
      ...data,
      hero: { ...data.hero, [field]: value }
    });
  };

  const updateAbout = (field: keyof AboutSection, value: any) => {
    onChange({
      ...data,
      about: { ...data.about, [field]: value }
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: 'heroProfile' | 'heroBanner' | 'aboutProfile') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(target);
    try {
      const res = await uploadMediaFile(token, file);
      if (target === 'heroProfile') updateHero('profileImage', res.url);
      else if (target === 'heroBanner') updateHero('bannerImage', res.url);
      else if (target === 'aboutProfile') updateAbout('profileImage', res.url);
    } catch (err: any) {
      alert('Upload failed: ' + err.message);
    } finally {
      setUploadingImage(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-4">
        <button
          onClick={() => setSubTab('hero')}
          className={`px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition-all flex items-center gap-2 ${
            subTab === 'hero'
              ? 'bg-amber-500 text-neutral-950 shadow-md'
              : 'bg-neutral-900 text-neutral-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Hero Section</span>
        </button>
        <button
          onClick={() => setSubTab('about')}
          className={`px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition-all flex items-center gap-2 ${
            subTab === 'about'
              ? 'bg-amber-500 text-neutral-950 shadow-md'
              : 'bg-neutral-900 text-neutral-400 hover:text-white'
          }`}
        >
          <User className="w-4 h-4" />
          <span>About Me & Bio</span>
        </button>
      </div>

      {/* HERO EDITOR */}
      {subTab === 'hero' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl border border-white/10 bg-neutral-900/60 space-y-4">
            <h3 className="text-base font-bold text-neutral-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Hero Branding & Headings
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Main Title (Headline)</label>
                <input
                  type="text"
                  value={hero.title}
                  onChange={(e) => updateHero('title', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                  placeholder="THE EDITOR"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Subtitle / Full Name</label>
                <input
                  type="text"
                  value={hero.subtitle}
                  onChange={(e) => updateHero('subtitle', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                  placeholder="Asma Shehzadi"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Tagline (Golden Text)</label>
                <input
                  type="text"
                  value={hero.tagline}
                  onChange={(e) => updateHero('tagline', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                  placeholder="Your Ideas, My Edit"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Availability Badge Text</label>
                <input
                  type="text"
                  value={hero.badgeText}
                  onChange={(e) => updateHero('badgeText', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                  placeholder="Available for Creative Projects"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Hero Lead Description</label>
              <textarea
                rows={3}
                value={hero.description}
                onChange={(e) => updateHero('description', e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          {/* Hero Buttons & Links */}
          <div className="p-6 rounded-2xl border border-white/10 bg-neutral-900/60 space-y-4">
            <h3 className="text-base font-bold text-neutral-100">Hero Buttons & Links</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Primary Button Text</label>
                <input
                  type="text"
                  value={hero.primaryBtnText}
                  onChange={(e) => updateHero('primaryBtnText', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Primary Button Target Link</label>
                <input
                  type="text"
                  value={hero.primaryBtnLink}
                  onChange={(e) => updateHero('primaryBtnLink', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                  placeholder="#contact"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Secondary Button Text</label>
                <input
                  type="text"
                  value={hero.secondaryBtnText}
                  onChange={(e) => updateHero('secondaryBtnText', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Secondary Button Target Link</label>
                <input
                  type="text"
                  value={hero.secondaryBtnLink}
                  onChange={(e) => updateHero('secondaryBtnLink', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                  placeholder="#video-portfolio"
                />
              </div>
            </div>
          </div>

          {/* Hero Images */}
          <div className="p-6 rounded-2xl border border-white/10 bg-neutral-900/60 space-y-4">
            <h3 className="text-base font-bold text-neutral-100 flex items-center gap-2">
              <Image className="w-4 h-4 text-amber-400" />
              Hero Visual Assets & Uploads
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Profile / Desk Image */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold text-neutral-300">
                  Featured Hero Photo (Editing Desk / Avatar)
                </label>
                <div className="relative aspect-video rounded-xl overflow-hidden border border-white/10 bg-neutral-950">
                  <img
                    src={hero.profileImage}
                    alt="Hero Desk"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={hero.profileImage}
                    onChange={(e) => updateHero('profileImage', e.target.value)}
                    className="flex-1 px-3 py-2 rounded-lg border border-white/10 bg-neutral-950 text-xs text-neutral-200"
                    placeholder="Image URL..."
                  />
                  <label className="px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs cursor-pointer flex items-center gap-1 shrink-0">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingImage === 'heroProfile' ? 'Uploading...' : 'Upload'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, 'heroProfile')}
                    />
                  </label>
                </div>
              </div>

              {/* Banner Image */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold text-neutral-300">
                  Branding Banner Graphic
                </label>
                <div className="relative aspect-video rounded-xl overflow-hidden border border-white/10 bg-neutral-950">
                  <img
                    src={hero.bannerImage}
                    alt="Hero Banner"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={hero.bannerImage}
                    onChange={(e) => updateHero('bannerImage', e.target.value)}
                    className="flex-1 px-3 py-2 rounded-lg border border-white/10 bg-neutral-950 text-xs text-neutral-200"
                    placeholder="Banner Image URL..."
                  />
                  <label className="px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs cursor-pointer flex items-center gap-1 shrink-0">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingImage === 'heroBanner' ? 'Uploading...' : 'Upload'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, 'heroBanner')}
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Hero Statistics Counters */}
          <div className="p-6 rounded-2xl border border-white/10 bg-neutral-900/60 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-neutral-100">Hero Statistics Numbers</h3>
              <button
                onClick={() => {
                  const newStats = [...hero.stats, { label: 'New Stat', value: '100+' }];
                  updateHero('stats', newStats);
                }}
                className="px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-semibold flex items-center gap-1 hover:bg-amber-500/30"
              >
                <Plus className="w-3.5 h-3.5" /> Add Stat
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {hero.stats.map((stat, idx) => (
                <div key={idx} className="p-3 rounded-xl border border-white/5 bg-neutral-950 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-amber-400">Stat #{idx + 1}</span>
                    <button
                      onClick={() => {
                        const newStats = hero.stats.filter((_, i) => i !== idx);
                        updateHero('stats', newStats);
                      }}
                      className="text-neutral-500 hover:text-red-400 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <input
                    type="text"
                    value={stat.value}
                    onChange={(e) => {
                      const newStats = [...hero.stats];
                      newStats[idx].value = e.target.value;
                      updateHero('stats', newStats);
                    }}
                    className="w-full px-3 py-1.5 rounded-lg border border-white/10 bg-neutral-900 text-sm font-bold text-amber-400"
                    placeholder="e.g. 500+"
                  />
                  <input
                    type="text"
                    value={stat.label}
                    onChange={(e) => {
                      const newStats = [...hero.stats];
                      newStats[idx].label = e.target.value;
                      updateHero('stats', newStats);
                    }}
                    className="w-full px-3 py-1 rounded-lg border border-white/10 bg-neutral-900 text-xs text-neutral-300"
                    placeholder="Label..."
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ABOUT EDITOR */}
      {subTab === 'about' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl border border-white/10 bg-neutral-900/60 space-y-4">
            <h3 className="text-base font-bold text-neutral-100 flex items-center gap-2">
              <User className="w-4 h-4 text-amber-400" />
              About Me Titles & Persona
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Section Title</label>
                <input
                  type="text"
                  value={about.title}
                  onChange={(e) => updateAbout('title', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Subtitle</label>
                <input
                  type="text"
                  value={about.subtitle}
                  onChange={(e) => updateAbout('subtitle', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Experience Years</label>
                <input
                  type="text"
                  value={about.experienceYears}
                  onChange={(e) => updateAbout('experienceYears', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">Signature Text</label>
                <input
                  type="text"
                  value={about.signatureText}
                  onChange={(e) => updateAbout('signatureText', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-neutral-100 text-sm focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            {/* Bio Paragraphs */}
            <div className="space-y-3 pt-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-neutral-200">Biography Paragraphs</label>
                <button
                  onClick={() => updateAbout('bio', [...about.bio, ''])}
                  className="px-2.5 py-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-[11px] font-semibold text-amber-400 flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" /> Add Paragraph
                </button>
              </div>

              {about.bio.map((para, idx) => (
                <div key={idx} className="flex gap-2 items-start">
                  <textarea
                    rows={2}
                    value={para}
                    onChange={(e) => {
                      const newBio = [...about.bio];
                      newBio[idx] = e.target.value;
                      updateAbout('bio', newBio);
                    }}
                    className="flex-1 px-4 py-2 rounded-xl border border-white/10 bg-neutral-950 text-xs md:text-sm text-neutral-200 focus:border-amber-400 focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      const newBio = about.bio.filter((_, i) => i !== idx);
                      updateAbout('bio', newBio);
                    }}
                    className="p-2 text-neutral-500 hover:text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Profile Avatar Image */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <label className="block text-xs font-semibold text-neutral-300">
                About Avatar / Portrait Image
              </label>
              <div className="flex items-center gap-4">
                <img
                  src={about.profileImage}
                  alt="Avatar"
                  className="w-16 h-16 rounded-full object-cover border-2 border-amber-400"
                />
                <input
                  type="text"
                  value={about.profileImage}
                  onChange={(e) => updateAbout('profileImage', e.target.value)}
                  className="flex-1 px-4 py-2.5 rounded-xl border border-white/10 bg-neutral-950 text-xs text-neutral-200"
                />
                <label className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs cursor-pointer flex items-center gap-1 shrink-0">
                  <Upload className="w-4 h-4" />
                  <span>{uploadingImage === 'aboutProfile' ? 'Uploading...' : 'Upload'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, 'aboutProfile')}
                  />
                </label>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
