import { WebsiteData } from '../types';
import { initialWebsiteData } from '../data/initialData';

const BASE_URL = (import.meta as any).env?.VITE_API_URL || '';
const LOCAL_STORAGE_KEY = 'the_editor_website_data';

export async function getWebsiteData(): Promise<WebsiteData> {
  // First priority: check if user has saved custom data in localStorage
  try {
    const local = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (local) {
      const parsed = JSON.parse(local);
      if (parsed && parsed.hero && parsed.videos) {
        if (!parsed.pricingSettings) {
          parsed.pricingSettings = initialWebsiteData.pricingSettings;
        }
        if (!parsed.theme) {
          parsed.theme = initialWebsiteData.theme;
        } else {
          if (!parsed.theme.sectionColors) parsed.theme.sectionColors = {};
          if (!parsed.theme.sectionAnimations) parsed.theme.sectionAnimations = {};
          if (!parsed.theme.darkColors) parsed.theme.darkColors = initialWebsiteData.theme.darkColors;
          if (!parsed.theme.lightColors) parsed.theme.lightColors = initialWebsiteData.theme.lightColors;
        }
        if (parsed.services) {
          parsed.services = parsed.services.map((s: any, idx: number) => {
            if (!s.prices && initialWebsiteData.services[idx]?.prices) {
              return { ...s, prices: initialWebsiteData.services[idx].prices };
            }
            return s;
          });
        }
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Error reading from localStorage:', err);
  }

  // Second priority: try fetching from server / Netlify function
  try {
    const res = await fetch(`${BASE_URL}/api/content`);
    if (res.ok) {
      const serverData = await res.json();
      if (serverData && serverData.hero) {
        if (!serverData.pricingSettings) {
          serverData.pricingSettings = initialWebsiteData.pricingSettings;
        }
        if (!serverData.theme) {
          serverData.theme = initialWebsiteData.theme;
        } else {
          if (!serverData.theme.sectionColors) serverData.theme.sectionColors = {};
          if (!serverData.theme.sectionAnimations) serverData.theme.sectionAnimations = {};
          if (!serverData.theme.darkColors) serverData.theme.darkColors = initialWebsiteData.theme.darkColors;
          if (!serverData.theme.lightColors) serverData.theme.lightColors = initialWebsiteData.theme.lightColors;
        }
        if (serverData.services) {
          serverData.services = serverData.services.map((s: any, idx: number) => {
            if (!s.prices && initialWebsiteData.services[idx]?.prices) {
              return { ...s, prices: initialWebsiteData.services[idx].prices };
            }
            return s;
          });
        }
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(serverData));
        return serverData;
      }
    }
  } catch (err) {
    console.warn('Backend /api/content not reachable, using fallback:', err);
  }

  return initialWebsiteData;
}

export async function updateWebsiteData(token: string, data: WebsiteData): Promise<WebsiteData> {
  data.lastUpdated = new Date().toISOString();

  // Ensure theme structure is pristine before saving
  if (!data.theme) {
    data.theme = initialWebsiteData.theme;
  }
  if (!data.theme.sectionColors) {
    data.theme.sectionColors = {};
  }

  // Always persist locally first so changes are immediate, persistent, and never lost
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('Failed to save to localStorage:', e);
  }

  // Also sync to backend API / Netlify function
  try {
    const res = await fetch(`${BASE_URL}/api/content`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(data)
    });

    if (res.ok) {
      const result = await res.json();
      return result.data || data;
    }
  } catch (err) {
    console.warn('Backend API update not reachable, saved to local cache:', err);
  }

  return data;
}

const CUSTOM_CREDENTIALS_KEY = 'the_editor_custom_credentials';

export interface CredentialsInfo {
  username: string;
  isCustom: boolean;
}

export function getActiveCredentialsInfo(): CredentialsInfo {
  try {
    const raw = localStorage.getItem(CUSTOM_CREDENTIALS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.username) {
        return { username: parsed.username, isCustom: true };
      }
    }
  } catch {
    // fallback
  }
  return { username: 'admin', isCustom: false };
}

export async function loginAdmin(username: string, password: string): Promise<{ token: string; user: any }> {
  const cleanUser = (username || '').trim().toLowerCase();

  // 1. Check active credentials store (from localStorage if custom credentials exist)
  let activeUser = 'admin';
  let activePass = 'editor2026';
  let hasCustom = false;
  try {
    const raw = localStorage.getItem(CUSTOM_CREDENTIALS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.username && parsed.password) {
        activeUser = parsed.username.trim();
        activePass = parsed.password.trim();
        hasCustom = true;
      }
    }
  } catch {
    // fallback
  }

  // If custom credentials were set, verify that user is NOT trying to login with old credentials
  if (hasCustom) {
    if (password === 'editor2026' && activePass !== 'editor2026') {
      throw new Error('Invalid credentials. The previous password has been changed and is no longer valid. Please use your updated password.');
    }
    if (cleanUser === 'admin' && activeUser.toLowerCase() !== 'admin') {
      throw new Error('Invalid credentials. The admin username has been changed. Please use your updated username.');
    }
  }

  // Try authenticating with backend (e.g. server.ts or Netlify function)
  try {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    if (res.ok) {
      const json = await res.json();
      if (json && json.token) {
        localStorage.setItem('the_editor_admin_token', json.token);
      }
      return json;
    }
  } catch (err) {
    console.warn('Backend login request error:', err);
  }

  // Client-side authentication against active credentials:
  // This ensures that when credentials are updated (or deployed in serverless/static environments where
  // Netlify env vars have not yet restarted), the user's saved updated credentials work reliably and immediately.
  if (cleanUser === activeUser.toLowerCase() && password === activePass) {
    const clientPayload = { username: activeUser, role: 'Super Admin', exp: Date.now() + 7 * 24 * 60 * 60 * 1000 };
    const dummyToken = `client.${btoa(JSON.stringify(clientPayload))}.hash`;
    localStorage.setItem('the_editor_admin_token', dummyToken);
    return {
      token: dummyToken,
      user: { username: activeUser, name: 'Asma Shehzadi', role: 'Super Admin' }
    };
  }

  throw new Error('Invalid username or password. Please verify your credentials.');
}

export async function changeAdminCredentials(
  token: string,
  credentials: { currentPassword: string; newUsername?: string; newPassword?: string }
): Promise<{ success: boolean; message: string; token?: string; user?: any }> {
  // 1. Verify current password against active credentials
  let activePass = 'editor2026';
  let activeUser = 'admin';
  try {
    const raw = localStorage.getItem(CUSTOM_CREDENTIALS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.password) activePass = parsed.password;
      if (parsed.username) activeUser = parsed.username;
    }
  } catch {
    // fallback
  }

  if (credentials.currentPassword !== activePass) {
    throw new Error('Current password does not match your active password.');
  }

  if (credentials.newPassword && credentials.newPassword.trim().length < 6) {
    throw new Error('New password must be at least 6 characters long.');
  }

  const updatedUser = credentials.newUsername?.trim() || activeUser;
  const updatedPass = credentials.newPassword?.trim() || activePass;

  // Persist locally first so changes are immediate, persistent, and permanent
  localStorage.setItem(CUSTOM_CREDENTIALS_KEY, JSON.stringify({
    username: updatedUser,
    password: updatedPass
  }));

  let serverRes: any = null;
  try {
    const res = await fetch(`${BASE_URL}/api/auth/change-credentials`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({
        currentPassword: credentials.currentPassword,
        newUsername: updatedUser,
        newPassword: updatedPass
      })
    });
    if (res.ok) {
      serverRes = await res.json();
      if (serverRes.token) {
        localStorage.setItem('the_editor_admin_token', serverRes.token);
      }
    }
  } catch (err) {
    console.warn('Backend change-credentials offline, saved locally:', err);
  }

  // Generate fresh valid token
  const clientPayload = { username: updatedUser, role: 'Super Admin', exp: Date.now() + 7 * 24 * 60 * 60 * 1000 };
  const freshToken = serverRes?.token || `client.${btoa(JSON.stringify(clientPayload))}.hash`;
  localStorage.setItem('the_editor_admin_token', freshToken);

  return {
    success: true,
    message: 'Admin credentials updated and saved successfully! The previous credentials will no longer work.',
    token: freshToken,
    user: { username: updatedUser, name: 'Asma Shehzadi', role: 'Super Admin' }
  };
}

export async function verifyToken(token: string): Promise<boolean> {
  try {
    const res = await fetch(`${BASE_URL}/api/auth/verify`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.ok) {
      const json = await res.json();
      return Boolean(json.valid);
    }
  } catch {
    // If backend is momentarily unreachable, check if token is valid JWT structure
    try {
      const parts = token.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(atob(parts[1]));
        if (payload.exp && payload.exp > Date.now()) {
          return true;
        }
      }
    } catch {
      return false;
    }
  }
  return false;
}

export async function uploadMediaFile(token: string, file: File): Promise<{ url: string; filename: string; size: number }> {
  // If backend supports multipart upload
  try {
    const formData = new FormData();
    formData.append('file', file);

    const res = await fetch(`${BASE_URL}/api/upload`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`
      },
      body: formData
    });

    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('Server upload not reachable, converting to base64 DataURL:', err);
  }

  // Graceful client-side fallback: Convert image to DataURL for immediate browser persistence
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      resolve({
        url: reader.result as string,
        filename: file.name,
        size: file.size
      });
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

export async function getMediaLibrary(token: string): Promise<any[]> {
  try {
    const res = await fetch(`${BASE_URL}/api/media`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.ok) return await res.json();
  } catch {
    // fallback
  }
  return [];
}

export async function deleteMediaFile(token: string, filename: string): Promise<void> {
  try {
    await fetch(`${BASE_URL}/api/media/${encodeURIComponent(filename)}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });
  } catch {
    // ignore
  }
}

export async function resetDemoData(token: string): Promise<WebsiteData> {
  localStorage.removeItem(LOCAL_STORAGE_KEY);
  try {
    const res = await fetch(`${BASE_URL}/api/reset-demo`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.ok) {
      const json = await res.json();
      return json.data;
    }
  } catch {
    // ignore
  }
  return initialWebsiteData;
}

export async function restoreDatabase(token: string, backupData: any): Promise<WebsiteData> {
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(backupData));
  try {
    const res = await fetch(`${BASE_URL}/api/restore`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(backupData)
    });
    if (res.ok) {
      const json = await res.json();
      return json.data;
    }
  } catch {
    // fallback
  }
  return backupData;
}
