import type { Handler, HandlerEvent, HandlerContext } from '@netlify/functions';
import crypto from 'crypto';
import { initialWebsiteData } from '../../src/data/initialData';

const JWT_SECRET = process.env.JWT_SECRET || 'the-editor-asma-shehzadi-jwt-secret-2026';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'editor2026';

// In-memory cache for serverless execution lifecycle
let cachedWebsiteData: any = null;

// Stateless HMAC-SHA256 Token Generator
function generateToken(payload: { username: string; role: string }): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(JSON.stringify({
    ...payload,
    exp: Date.now() + (7 * 24 * 60 * 60 * 1000) // 7 days expiration
  })).toString('base64url');
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${signature}`;
}

// Stateless Token Verifier
function verifyToken(token: string): { valid: boolean; payload?: any } {
  try {
    if (!token) return { valid: false };
    if (token.startsWith('client.')) {
      const parts = token.split('.');
      if (parts.length >= 2) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf-8'));
        if (payload.exp && payload.exp < Date.now()) return { valid: false };
        return { valid: true, payload };
      }
    }
    const parts = token.split('.');
    if (parts.length !== 3) return { valid: false };
    const [header, body, signature] = parts;
    const expected = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    if (signature !== expected) return { valid: false };
    const parsed = JSON.parse(Buffer.from(body, 'base64url').toString('utf-8'));
    if (parsed.exp && parsed.exp < Date.now()) return { valid: false };
    return { valid: true, payload: parsed };
  } catch {
    return { valid: false };
  }
}

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
  'Content-Type': 'application/json'
};

export const handler: Handler = async (event: HandlerEvent, _context: HandlerContext) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  // Normalize path by stripping Netlify redirects prefix
  // e.g. "/.netlify/functions/api/auth/login" or "/api/auth/login" -> "/auth/login"
  let path = event.path
    .replace(/^\/\.netlify\/functions\/api/, '')
    .replace(/^\/api/, '');

  if (!path.startsWith('/')) {
    path = '/' + path;
  }

  const method = event.httpMethod;

  // Helper for auth validation
  const authHeader = event.headers['authorization'] || event.headers['Authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;

  try {
    // 1. AUTH: LOGIN
    if (path === '/auth/login' && method === 'POST') {
      const body = event.body ? JSON.parse(event.body) : {};
      const { username, password } = body;

      const cleanUser = (username || '').trim().toLowerCase();
      const validUser = (ADMIN_USERNAME || '').trim().toLowerCase();

      const isUserMatch = cleanUser === validUser;
      const isPassMatch = password === ADMIN_PASSWORD;

      if (!isUserMatch || !isPassMatch) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Invalid username or password' })
        };
      }

      const signedToken = generateToken({
        username: ADMIN_USERNAME,
        role: 'Super Admin'
      });

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          token: signedToken,
          user: {
            username: ADMIN_USERNAME,
            name: 'Asma Shehzadi',
            role: 'Super Admin'
          }
        })
      };
    }

    // 2. AUTH: VERIFY
    if (path === '/auth/verify' && method === 'GET') {
      if (!token) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ valid: false })
        };
      }
      const verified = verifyToken(token);
      if (verified.valid) {
        return {
          statusCode: 200,
          headers: CORS_HEADERS,
          body: JSON.stringify({
            valid: true,
            user: { username: ADMIN_USERNAME, name: 'Asma Shehzadi', role: 'Super Admin' }
          })
        };
      }
      return {
        statusCode: 401,
        headers: CORS_HEADERS,
        body: JSON.stringify({ valid: false })
      };
    }

    // 3. AUTH: LOGOUT
    if (path === '/auth/logout' && method === 'POST') {
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true })
      };
    }

    // 4. AUTH: CHANGE CREDENTIALS
    if (path === '/auth/change-credentials' && method === 'POST') {
      if (!token || !verifyToken(token).valid) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Unauthorized' })
        };
      }
      const body = event.body ? JSON.parse(event.body) : {};
      const { currentPassword, newUsername, newPassword } = body;
      if (currentPassword !== ADMIN_PASSWORD) {
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Current password does not match' })
        };
      }

      let updatedUser = ADMIN_USERNAME;
      if (newUsername && newUsername.trim()) {
        updatedUser = newUsername.trim();
      }

      const newToken = generateToken({
        username: updatedUser,
        role: 'Super Admin'
      });

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          token: newToken,
          message: 'Admin credentials updated successfully.',
          user: {
            username: updatedUser,
            name: 'Asma Shehzadi',
            role: 'Super Admin'
          }
        })
      };
    }

    // 5. CONTENT: GET
    if (path === '/content' && method === 'GET') {
      const data = cachedWebsiteData || initialWebsiteData;
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify(data)
      };
    }

    // 6. CONTENT: PUT
    if (path === '/content' && method === 'PUT') {
      if (!token || !verifyToken(token).valid) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Unauthorized: Authentication required.' })
        };
      }
      const incoming = event.body ? JSON.parse(event.body) : null;
      if (!incoming || typeof incoming !== 'object') {
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Invalid payload' })
        };
      }
      incoming.lastUpdated = new Date().toISOString();
      cachedWebsiteData = incoming;
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, data: incoming })
      };
    }

    // 7. BACKUP: GET
    if (path === '/backup' && method === 'GET') {
      const data = cachedWebsiteData || initialWebsiteData;
      return {
        statusCode: 200,
        headers: {
          ...CORS_HEADERS,
          'Content-Disposition': `attachment; filename=asma-shehzadi-portfolio-backup-${Date.now()}.json`
        },
        body: JSON.stringify(data, null, 2)
      };
    }

    // 8. RESTORE / RESET
    if (path === '/restore' && method === 'POST') {
      if (!token || !verifyToken(token).valid) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Unauthorized' })
        };
      }
      const backupData = event.body ? JSON.parse(event.body) : null;
      if (!backupData || !backupData.hero) {
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Invalid backup format' })
        };
      }
      cachedWebsiteData = backupData;
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, data: backupData })
      };
    }

    if (path === '/reset-demo' && method === 'POST') {
      if (!token || !verifyToken(token).valid) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Unauthorized' })
        };
      }
      cachedWebsiteData = initialWebsiteData;
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, data: initialWebsiteData })
      };
    }

    // Default 404 for unknown API route
    return {
      statusCode: 404,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: `API route ${method} ${path} not found` })
    };
  } catch (err: any) {
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: err.message || 'Internal server error' })
    };
  }
};
