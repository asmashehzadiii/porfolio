import React, { useState, useEffect } from 'react';
import { HardDrive, Upload, Trash2, Copy, CheckCircle2, Film, Image, RefreshCw, FileText } from 'lucide-react';
import { getMediaLibrary, deleteMediaFile, uploadMediaFile } from '../../services/api';

interface MediaLibraryTabProps {
  token: string;
}

export const MediaLibraryTab: React.FC<MediaLibraryTabProps> = ({ token }) => {
  const [mediaList, setMediaList] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'image' | 'video'>('all');

  const fetchMedia = async () => {
    setLoading(true);
    try {
      const items = await getMediaLibrary(token);
      setMediaList(items);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMedia();
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    try {
      for (let i = 0; i < files.length; i++) {
        await uploadMediaFile(token, files[i]);
      }
      await fetchMedia();
    } catch (err: any) {
      alert('Upload failed: ' + err.message);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDelete = async (filename: string) => {
    if (confirm(`Delete file "${filename}" from server storage?`)) {
      try {
        await deleteMediaFile(token, filename);
        setMediaList(mediaList.filter(m => m.filename !== filename));
      } catch (err: any) {
        alert('Delete failed: ' + err.message);
      }
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  const filteredMedia = mediaList.filter(item => {
    if (filterType === 'all') return true;
    return item.type === filterType;
  });

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl border border-white/10 bg-neutral-900/60">
        <div>
          <h2 className="text-xl font-bold text-neutral-100 flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-amber-400" />
            Media Storage & Uploads Library
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Persistent server storage for video files, portfolio thumbnails, and graphics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchMedia}
            className="p-2.5 rounded-xl border border-white/10 bg-neutral-800 text-neutral-300 hover:text-white"
            title="Refresh library"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <label className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-transform hover:scale-105">
            <Upload className="w-4 h-4" />
            <span>{uploading ? 'Uploading...' : 'Upload Media Files'}</span>
            <input
              type="file"
              multiple
              className="hidden"
              onChange={handleFileUpload}
            />
          </label>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-2">
        {(['all', 'image', 'video'] as const).map(type => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold capitalize ${
              filterType === type
                ? 'bg-amber-500 text-neutral-950 font-bold'
                : 'bg-neutral-900 text-neutral-400 hover:text-white border border-white/5'
            }`}
          >
            {type}s
          </button>
        ))}
      </div>

      {/* Media Grid */}
      {filteredMedia.length === 0 ? (
        <div className="p-16 text-center rounded-2xl border border-dashed border-white/10 bg-neutral-950">
          <HardDrive className="w-10 h-10 text-neutral-600 mx-auto mb-2" />
          <p className="text-xs text-neutral-400">No media files found in this category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredMedia.map((media) => (
            <div
              key={media.filename}
              className="p-3 rounded-2xl border border-white/10 bg-neutral-950 flex flex-col justify-between group hover:border-amber-400/50 transition-all"
            >
              <div className="relative aspect-square rounded-xl overflow-hidden bg-neutral-900 flex items-center justify-center border border-white/5">
                {media.type === 'image' ? (
                  <img
                    src={media.url}
                    alt={media.filename}
                    className="w-full h-full object-cover"
                  />
                ) : media.type === 'video' ? (
                  <div className="flex flex-col items-center gap-1 text-amber-400">
                    <Film className="w-8 h-8" />
                    <span className="text-[10px] font-bold text-neutral-300">Video MP4</span>
                  </div>
                ) : (
                  <FileText className="w-8 h-8 text-neutral-400" />
                )}
              </div>

              <div className="mt-2 space-y-1">
                <p className="text-[11px] font-bold text-neutral-200 truncate" title={media.filename}>
                  {media.filename}
                </p>
                <div className="flex items-center justify-between text-[10px] text-neutral-500">
                  <span>{(media.size / 1024 / 1024).toFixed(1)} MB</span>
                  <span className="capitalize">{media.type}</span>
                </div>
              </div>

              <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between">
                <button
                  onClick={() => copyToClipboard(media.url)}
                  className="px-2 py-1 rounded bg-neutral-900 hover:bg-neutral-800 text-[10px] font-semibold text-neutral-300 hover:text-amber-400 flex items-center gap-1"
                >
                  {copiedUrl === media.url ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-amber-400" />}
                  <span>{copiedUrl === media.url ? 'Copied' : 'Copy URL'}</span>
                </button>
                <button
                  onClick={() => handleDelete(media.filename)}
                  className="p-1 text-neutral-500 hover:text-red-400"
                  title="Delete File"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
