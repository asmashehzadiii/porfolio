import React, { useEffect } from 'react';
import { X, ExternalLink, Calendar, Eye, Tag, Film } from 'lucide-react';
import { VideoItem } from '../types';

interface VideoModalProps {
  video: VideoItem | null;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ video, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (video) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [video, onClose]);

  if (!video) return null;

  // Helper to extract YouTube embed URL
  const getEmbedUrl = (url: string, type: string) => {
    if (type === 'upload' || type === 'direct_url') {
      return url;
    }
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      let videoId = '';
      if (url.includes('youtu.be/')) {
        videoId = url.split('youtu.be/')[1].split('?')[0];
      } else if (url.includes('shorts/')) {
        videoId = url.split('shorts/')[1].split('?')[0];
      } else if (url.includes('v=')) {
        videoId = url.split('v=')[1].split('&')[0];
      }
      return videoId ? `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0` : url;
    }
    if (url.includes('vimeo.com')) {
      const vimeoId = url.split('/').filter(Boolean).pop();
      return `https://player.vimeo.com/video/${vimeoId}?autoplay=1`;
    }
    return url;
  };

  const isDirectVideo = video.videoType === 'upload' || video.videoUrl.endsWith('.mp4') || video.videoUrl.endsWith('.webm');
  const embedUrl = getEmbedUrl(video.videoUrl, video.videoType);
  const isVertical = video.aspectRatio === '9:16';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/90 backdrop-blur-xl animate-in fade-in duration-200">
      {/* Background click to close */}
      <div className="absolute inset-0" onClick={onClose} />

      <div className={`relative z-10 w-full ${isVertical ? 'max-w-md' : 'max-w-5xl'} max-h-[92vh] flex flex-col rounded-2xl bg-neutral-950 border border-white/10 shadow-2xl overflow-hidden`}>
        {/* Header bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-neutral-900/80">
          <div className="flex items-center gap-2.5 truncate">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30">
              {video.category}
            </span>
            <h3 className="text-base font-semibold text-neutral-100 truncate">{video.title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Close (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player */}
        <div className={`w-full bg-black flex items-center justify-center ${isVertical ? 'aspect-[9/16] max-h-[60vh]' : 'aspect-video'}`}>
          {isDirectVideo ? (
            <video
              src={embedUrl}
              controls
              autoPlay
              playsInline
              poster={video.thumbnailUrl}
              className="w-full h-full object-contain"
            />
          ) : (
            <iframe
              src={embedUrl}
              title={video.title}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          )}
        </div>

        {/* Meta & Description */}
        <div className="p-5 overflow-y-auto max-h-48 text-sm space-y-3 bg-neutral-950/95">
          <div className="flex flex-wrap items-center gap-4 text-xs text-neutral-400">
            {video.clientName && (
              <span className="flex items-center gap-1 text-neutral-300">
                <Film className="w-3.5 h-3.5 text-amber-400" /> Client: <strong>{video.clientName}</strong>
              </span>
            )}
            {video.viewsCount && (
              <span className="flex items-center gap-1 text-neutral-300">
                <Eye className="w-3.5 h-3.5 text-amber-400" /> {video.viewsCount}
              </span>
            )}
            {video.duration && (
              <span>Duration: {video.duration}</span>
            )}
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> {video.createdAt?.slice(0, 10)}
            </span>
          </div>

          <p className="text-neutral-300 text-sm leading-relaxed">{video.description}</p>

          {video.tags && video.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {video.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded-md bg-neutral-900 text-xs text-neutral-400 border border-neutral-800 flex items-center gap-1"
                >
                  <Tag className="w-3 h-3 text-amber-400/70" />
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
