import type { Handler, HandlerEvent, HandlerContext } from '@netlify/functions';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { initialWebsiteData } from '../../src/data/initialData';

const JWT_SECRET = process.env.JWT_SECRET || 'the-editor-asma-shehzadi-jwt-secret-2026';
const DATA_DIR = path.resolve(process.cwd(), 'data');
const AUTH_FILE = path.join(DATA_DIR, 'auth_config.json');

interface AuthConfig {
  username: string;
  passwordHash: string;
  tokenSecret: string;
}

function hashPassword(password: string, salt: string): string {
  return crypto.createHmac('sha256', salt).update(password).digest('hex');
}

function verifyPassword(candidate: string, stored: string): boolean {
  if (!candidate || !stored) return false;
  if (stored.startsWith('sha256:')) {
    const parts = stored.split(':');
    if (parts.length === 3) {
      const storedSalt = parts[1];
      const storedHash = parts[2];
      return hashPassword(candidate, storedSalt) === storedHash;
    }
  }
  return candidate === stored;
}

const DEFAULT_SALT = crypto.randomBytes(16).toString('hex');
const DEFAULT_PASSWORD = process.env.ADMIN_PASSWORD || 'editor2026';
let inMemoryAuth: AuthConfig = {
  username: process.env.ADMIN_USERNAME || 'admin',
  passwordHash: `sha256:${DEFAULT_SALT}:${hashPassword(DEFAULT_PASSWORD, DEFAULT_SALT)}`,
  tokenSecret: crypto.randomBytes(24).toString('hex')
};

function getAuthConfig(): AuthConfig {
  try {
    if (fs.existsSync(AUTH_FILE)) {
      const raw = fs.readFileSync(AUTH_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && parsed.username && parsed.passwordHash) {
        return parsed;
      }
    }
  } catch {}
  return inMemoryAuth;
}

function saveAuthConfig(config: AuthConfig) {
  inMemoryAuth = config;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(AUTH_FILE, JSON.stringify(config, null, 2), 'utf-8');
  } catch {}
}

// In-memory cache for serverless execution lifecycle
let cachedWebsiteData: any = null;

// Stateless HMAC-SHA256 Token Generator
function generateToken(payload: { username: string; role: string }): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(JSON.stringify({
    ...payload,
    exp: Date.now() + (7 * 24 * 60 * 60 * 1000) // 7 days expiration
  })).toString('base64url');
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${signature}`;
}

// Stateless Token Verifier
function verifyToken(token: string): { valid: boolean; payload?: any } {
  try {
    if (!token) return { valid: false };
    if (token.startsWith('client.')) {
      const parts = token.split('.');
      if (parts.length >= 2) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf-8'));
        if (payload.exp && payload.exp < Date.now()) return { valid: false };
        return { valid: true, payload };
      }
    }
    const parts = token.split('.');
    if (parts.length !== 3) return { valid: false };
    const [header, body, signature] = parts;
    const expected = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    if (signature !== expected) return { valid: false };
    const parsed = JSON.parse(Buffer.from(body, 'base64url').toString('utf-8'));
    if (parsed.exp && parsed.exp < Date.now()) return { valid: false };
    return { valid: true, payload: parsed };
  } catch {
    return { valid: false };
  }
}

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
  'Content-Type': 'application/json'
};

export const handler: Handler = async (event: HandlerEvent, _context: HandlerContext) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  // Normalize path by stripping Netlify redirects prefix
  // e.g. "/.netlify/functions/api/auth/login" or "/api/auth/login" -> "/auth/login"
  let path = event.path
    .replace(/^\/\.netlify\/functions\/api/, '')
    .replace(/^\/api/, '');

  if (!path.startsWith('/')) {
    path = '/' + path;
  }

  const method = event.httpMethod;

  // Helper for auth validation
  const authHeader = event.headers['authorization'] || event.headers['Authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;

  try {
    // 1. AUTH: LOGIN
    if (path === '/auth/login' && method === 'POST') {
      const body = event.body ? JSON.parse(event.body) : {};
      const { username, password } = body;
      const auth = getAuthConfig();

      const cleanUser = (username || '').trim().toLowerCase();
      const validUser = (auth.username || '').trim().toLowerCase();

      const isUserMatch = cleanUser === validUser;
      const isPassMatch = verifyPassword(password, auth.passwordHash);

      if (!isUserMatch || !isPassMatch) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Invalid username or password' })
        };
      }

      const signedToken = generateToken({
        username: auth.username,
        role: 'Super Admin'
      });

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          token: signedToken,
          user: {
            username: auth.username,
            name: 'Asma Shehzadi',
            role: 'Super Admin'
          }
        })
      };
    }

    // 2. AUTH: VERIFY
    if (path === '/auth/verify' && method === 'GET') {
      if (!token) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ valid: false })
        };
      }
      const verified = verifyToken(token);
      if (verified.valid) {
        const auth = getAuthConfig();
        return {
          statusCode: 200,
          headers: CORS_HEADERS,
          body: JSON.stringify({
            valid: true,
            user: { username: auth.username, name: 'Asma Shehzadi', role: 'Super Admin' }
          })
        };
      }
      return {
        statusCode: 401,
        headers: CORS_HEADERS,
        body: JSON.stringify({ valid: false })
      };
    }

    // 3. AUTH: LOGOUT
    if (path === '/auth/logout' && method === 'POST') {
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true })
      };
    }

    // 4. AUTH: CHANGE CREDENTIALS
    if (path === '/auth/change-credentials' && method === 'POST') {
      if (!token || !verifyToken(token).valid) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Unauthorized' })
        };
      }
      const body = event.body ? JSON.parse(event.body) : {};
      const { currentPassword, newUsername, newPassword } = body;
      const auth = getAuthConfig();

      if (!verifyPassword(currentPassword, auth.passwordHash)) {
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Current password does not match' })
        };
      }

      let updatedUser = auth.username;
      if (newUsername && newUsername.trim()) {
        updatedUser = newUsername.trim();
        auth.username = updatedUser;
      }
      if (newPassword && newPassword.trim()) {
        if (newPassword.trim().length < 6) {
          return {
            statusCode: 400,
            headers: CORS_HEADERS,
            body: JSON.stringify({ error: 'New password must be at least 6 characters long' })
          };
        }
        const newSalt = crypto.randomBytes(16).toString('hex');
        auth.passwordHash = `sha256:${newSalt}:${hashPassword(newPassword.trim(), newSalt)}`;
      }

      saveAuthConfig(auth);

      const newToken = generateToken({
        username: updatedUser,
        role: 'Super Admin'
      });

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          token: newToken,
          message: 'Admin credentials updated and saved successfully! Old credentials will no longer work.',
          user: {
            username: updatedUser,
            name: 'Asma Shehzadi',
            role: 'Super Admin'
          }
        })
      };
    }

    // 5. CONTENT: GET
    if (path === '/content' && method === 'GET') {
      const data = cachedWebsiteData || initialWebsiteData;
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify(data)
      };
    }

    // 6. CONTENT: PUT
    if (path === '/content' && method === 'PUT') {
      if (!token || !verifyToken(token).valid) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Unauthorized: Authentication required.' })
        };
      }
      const incoming = event.body ? JSON.parse(event.body) : null;
      if (!incoming || typeof incoming !== 'object') {
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Invalid payload' })
        };
      }
      incoming.lastUpdated = new Date().toISOString();
      cachedWebsiteData = incoming;
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, data: incoming })
      };
    }

    // 7. BACKUP: GET
    if (path === '/backup' && method === 'GET') {
      const data = cachedWebsiteData || initialWebsiteData;
      return {
        statusCode: 200,
        headers: {
          ...CORS_HEADERS,
          'Content-Disposition': `attachment; filename=asma-shehzadi-portfolio-backup-${Date.now()}.json`
        },
        body: JSON.stringify(data, null, 2)
      };
    }

    // 8. RESTORE / RESET
    if (path === '/restore' && method === 'POST') {
      if (!token || !verifyToken(token).valid) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Unauthorized' })
        };
      }
      const backupData = event.body ? JSON.parse(event.body) : null;
      if (!backupData || !backupData.hero) {
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Invalid backup format' })
        };
      }
      cachedWebsiteData = backupData;
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, data: backupData })
      };
    }

    if (path === '/reset-demo' && method === 'POST') {
      if (!token || !verifyToken(token).valid) {
        return {
          statusCode: 401,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: 'Unauthorized' })
        };
      }
      cachedWebsiteData = initialWebsiteData;
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, data: initialWebsiteData })
      };
    }

    // Default 404 for unknown API route
    return {
      statusCode: 404,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: `API route ${method} ${path} not found` })
    };
  } catch (err: any) {
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: err.message || 'Internal server error' })
    };
  }
};
